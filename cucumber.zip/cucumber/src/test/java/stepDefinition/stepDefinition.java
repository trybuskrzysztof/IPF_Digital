package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
public class stepDefinition {

    @Given("^Ilosc gotowki na koncie wynosi 200 zl$")
    public void ilosc_gotowki_na_koncie_wynosi_200_zl() throws Throwable {
        throw new PendingException();
    }

    @When("^Uzytkownik probuje wyplacic 500 zl$")
    public void uzytkownik_probuje_wyplacic_500_zl() throws Throwable {
        throw new PendingException();
    }

    @When("^Uzytkownik probuje wyplacic (.+) zl$")
    public void uzytkownik_probuje_wyplacic_zl(String kwota) throws Throwable {
        throw new PendingException();
    }

    @Then("^Wyswietla sie error message$")
    public void wyswietla_sie_error_message() throws Throwable {
        throw new PendingException();
    }

    @Then("^Kwota, ktora probujemy wyplacic jest (.+)$")
    public void kwota_ktora_probujemy_wyplacic_jest(String poprawnosc) throws Throwable {
        throw new PendingException();
    }

    @And("^Wartosc wyplaconej gotowki wynosi 0 zl$")
    public void wartosc_wyplaconej_gotowki_wynosi_0_zl() throws Throwable {
        throw new PendingException();
    }

    @And("^Wartosc pieniedzy na koncie nadal wynosi 200 zl$")
    public void wartosc_pieniedzy_na_koncie_nadal_wynosi_200_zl() throws Throwable {
        throw new PendingException();
    }

    @And("^Wartosc pieniedzy na koncie jest (.+)$")
    public void wartosc_pieniedzy_na_koncie_jest(String czywystarczy) throws Throwable {
        throw new PendingException();
    }

}