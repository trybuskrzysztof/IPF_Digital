package testing;

import PageObjects.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import resources.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class MainPageTests extends base {

    @Test
    public void createAccount() throws IOException {
        driver = initializeDriver();
        driver.get("http://automationpractice.com/index.php");
        driver.manage().window().maximize();
        //one is inheritance
        //creating object to that class and invoke methods of
        base b=new base();
        MainPage m=new MainPage(driver);
        SignInPage s=new SignInPage(driver);
        CreateAccountPage c=new CreateAccountPage(driver);
        AccountPage a=new AccountPage(driver);

        m.getSignInButton().click();

        String newmail=b.generateString(10,"abcdefghijklmnopqrstuwvxyz1234567890") + "@gmail.com";
        System.out.println("generated email = " + newmail);
        String newpassword=b.generateString(8,"abcdefghijklmnopqrstuwvxyzABCDEFGHIJKLMNOPQRSTUWVXYZ1234567890");
        System.out.println("generated password = " + newpassword);

        s.getCreateEmail().sendKeys(newmail);
        s.getSubmitCreate().click();

        c.getGenderButton().click();
        c.getCustomerFirstName().sendKeys(b.getProperties("name"));
        c.getCustomerLastName().sendKeys(b.getProperties("surname"));
        c.getPassword().sendKeys(newpassword);
        c.getAddressField().sendKeys(b.getProperties("address"));
        c.getCityField().sendKeys(b.getProperties("city"));
        c.setStateToIndex(6);
        c.getPostalCode().sendKeys(b.getProperties("postcode"));
        c.getMobilePhone().sendKeys(b.getProperties("mobilephone"));

        c.getSubmitAccount().click();
        a.getSignoutbutton().click();
        driver.close();
    }

    @Test
    public void signInWithExistingAccount() throws IOException {
        driver = initializeDriver();
        driver.get("http://automationpractice.com/index.php");

        base b=new base();
        MainPage m=new MainPage(driver);
        SignInPage s=new SignInPage(driver);
        AccountPage a=new AccountPage(driver);

        m.getSignInButton().click();
        s.getEmailAddress().sendKeys(b.getProperties("signupusername"));
        s.getPassword().sendKeys(b.getProperties("signuppassword"));

        s.getSubmitButton().click();
        a.getSignoutbutton().click();

        driver.close();
    }

    @Test
    public void addAndRemoveItemFromCart() throws IOException, InterruptedException {
        driver = initializeDriver();
        driver.get("http://automationpractice.com/index.php");

        Actions action = new Actions(driver);
        base b=new base();
        MainPage m=new MainPage(driver);
        TShirtPage t=new TShirtPage(driver);

        m.getTshirtButton().click();
        m.getShortSleeveTshirt().click();
        t.getPlusButton().click();
        t.getSize("3");
        t.getColor().click();
        t.getSubmit().click();

        t.getContinueShoppingButton().click();
        action.moveToElement(t.getCart()).build().perform();
        t.getCross().click();
        Thread.sleep(5000);
        assert t.getEmptyCart().getText().equals("(empty)");
        driver.close();
    }
}