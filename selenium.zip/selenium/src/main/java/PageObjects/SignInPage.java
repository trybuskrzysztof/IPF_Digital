package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SignInPage {

    public WebDriver driver;

    By emailaddress=By.id("email");
    By passwd=By.id("passwd");
    By submitlogin=By.id("SubmitLogin");
    By createemail=By.id("email_create");
    By submitcreate=By.id("SubmitCreate");

    public SignInPage(WebDriver driver) {
        this.driver=driver;
    }

    public WebElement getEmailAddress() {
        return driver.findElement(emailaddress);
    }

    public WebElement getPassword() {
        return driver.findElement(passwd);
    }

    public WebElement getSubmitButton() {
        return driver.findElement(submitlogin);
    }

    public WebElement getCreateEmail() {
        return driver.findElement(createemail);
    }

    public WebElement getSubmitCreate() {
        return driver.findElement(submitcreate);
    }

}
