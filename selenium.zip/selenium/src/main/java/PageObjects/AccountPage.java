package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AccountPage {
    public WebDriver driver;

    public AccountPage(WebDriver driver) {
        this.driver=driver;
    }

    By signoutbutton=By.xpath("/html/body/div/div[1]/header/div[2]/div/div/nav/div[2]/a");

    public WebElement getSignoutbutton() {
        return driver.findElement(signoutbutton);
    }
}
