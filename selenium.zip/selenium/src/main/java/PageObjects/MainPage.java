package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import sun.applet.Main;

public class MainPage {

    public WebDriver driver;

    By signinbutton=By.xpath("/html/body/div/div[1]/header/div[2]/div/div/nav/div[1]/a");
    By tshirtbutton=By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[3]/a");
    By shortsleevetshirt=By.xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li/div/div[1]/div/a[1]/img");

    public MainPage(WebDriver driver) {
        this.driver=driver;
    }

    public WebElement getSignInButton() {
        return driver.findElement(signinbutton);
    }

    public WebElement getTshirtButton() { return driver.findElement(tshirtbutton);}

    public WebElement getShortSleeveTshirt() { return driver.findElement(shortsleevetshirt);}
}
