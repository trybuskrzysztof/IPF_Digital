package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class TShirtPage {

    public WebDriver driver;

    By plusbutton=By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[2]/p[1]/a[2]/span/i");
    By size=By.id("group_1");
    By color=By.id("color_14");
    By submit=By.name("Submit");
    By continueshoppingbutton=By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span");
    By cart=By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a");
    By cross=By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/div/div/div/dl/dt/span/a");
    By emptycart=By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a/span[5]");

    public TShirtPage (WebDriver driver) {
        this.driver=driver;
    }

    public WebElement getPlusButton() {
        return driver.findElement(plusbutton);
    }

    public WebElement getColor() {
        return driver.findElement(color);
    }

    public WebElement getSubmit() {
        return driver.findElement(submit);
    }

    public void getSize(String value) {
        Select sizeselect=new Select(driver.findElement(size));
        sizeselect.selectByValue(value);
    }

    public WebElement getContinueShoppingButton() {
        return driver.findElement(continueshoppingbutton);
    }

    public WebElement getCart() {
        return driver.findElement(cart);
    }

    public WebElement getCross() {
        return driver.findElement(cross);
    }

    public WebElement getEmptyCart() {
        return driver.findElement(emptycart);
    }
}