package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class CreateAccountPage {

    public WebDriver driver;

    By genderbutton=By.id("id_gender1");
    By customerfirstname=By.id("customer_firstname");
    By customerlastname=By.id("customer_lastname");
    By passwd=By.id("passwd");
    By addressfield=By.id("address1");
    By cityfield=By.id("city");
    By statefield=By.id("id_state");
    By postalcode=By.id("postcode");
    By mobilephone=By.id("phone_mobile");
    By submitaccount=By.id("submitAccount");

    public CreateAccountPage(WebDriver driver) {
        this.driver=driver;
    }

    public WebElement getGenderButton() {
        return driver.findElement(genderbutton);
    }

    public WebElement getCustomerFirstName() {
        return driver.findElement(customerfirstname);
    }

    public WebElement getCustomerLastName() {
        return driver.findElement(customerlastname);
    }

    public WebElement getPassword() {
        return driver.findElement(passwd);
    }

    public WebElement getAddressField() {
        return driver.findElement(addressfield);
    }

    public WebElement getCityField() {
        return driver.findElement(cityfield);
    }

    public void setStateToIndex(int statenumber) {
        Select statedropdown=new Select(driver.findElement(statefield));
        statedropdown.selectByIndex(statenumber);
    }

    public WebElement getPostalCode() {
        return driver.findElement(postalcode);
    }

    public WebElement getMobilePhone() {
        return driver.findElement(mobilephone);
    }

    public WebElement getSubmitAccount() {
        return driver.findElement(submitaccount);
    }

}
