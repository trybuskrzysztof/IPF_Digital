package resources;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class base {

    public WebDriver driver;

    public String getProperties(String property) throws IOException {

        Properties prop = new Properties();
        FileInputStream fis = new FileInputStream("C:\\Users\\ktrybus\\IdeaProjects\\selenium\\src\\main\\java\\resources\\data.properties");

        prop.load(fis);
        String dataproperty = prop.getProperty(property);
        return dataproperty;
    }

    public String generateString(int codeLength, String id){
        char[] chars = id.toCharArray();
        StringBuilder sb = new StringBuilder();
        Random random = new SecureRandom();
        for (int i = 0; i < codeLength; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        String output = sb.toString();
        System.out.println(output);
        return output;
    }

    public WebDriver initializeDriver() throws IOException {
        Properties prop2 = new Properties();
        FileInputStream fis2 = new FileInputStream("C:\\Users\\ktrybus\\IdeaProjects\\frameworkTest\\src\\main\\java\\resources\\data.properties");

        prop2.load(fis2);
        String browserName = prop2.getProperty("browser");

//        String browserName = getProperties("browser");

        if (browserName.equals("chrome")) {
            //execute in chrome driver
            System.setProperty("webdriver.chrome.driver","C:\\SeleniumUtils\\drivers\\chromedriver.exe");
            driver = new ChromeDriver();
        } else if (browserName.equals("firefox")) {
            //execute in firefox
            System.setProperty("webdriver.chrome.driver","C:\\SeleniumUtils\\drivers\\geckodriver.exe");
            driver = new FirefoxDriver();
        } else if (browserName.equals("edge")) {
            //execute in Internet Explorer
            System.setProperty("webdriver.chrome.driver","C:\\SeleniumUtils\\drivers\\msedgedriver.exe");
            driver = new EdgeDriver();
        }

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return driver;
    }
}